﻿/*
 * Created by SharpDevelop.
 * User: admin
 * Date: 17/12/2019
 * Time: 19:23
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace BlackJack
{
	class Program
	{
		public static void Main(string[] args)
		{
		
			
			BlackJack bj = new BlackJack();
			bj.ConstruireJeu();
			//bj.AfficherJeu();
			
		
		}
	}
}